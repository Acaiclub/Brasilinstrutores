
import React, { useState } from 'react';
import { Instructor, User, LessonBooking } from '../types';

interface PaymentModalProps {
  instructor: Instructor;
  user: User;
  onClose: () => void;
  onSuccess: (booking: LessonBooking) => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ instructor, user, onClose, onSuccess }) => {
  const [hours, setHours] = useState(1);
  const [date, setDate] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const total = hours * instructor.pricePerHour;

  const handlePayment = () => {
    if (!date) return alert('Selecione uma data para a aula');
    
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      const newBooking: LessonBooking = {
        id: Math.random().toString(36).substr(2, 9),
        instructorId: instructor.id,
        instructorName: instructor.name,
        studentId: user.id,
        date: date,
        hours: hours,
        totalAmount: total,
        status: 'confirmed'
      };
      setIsProcessing(false);
      onSuccess(newBooking);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
        <div className="bg-blue-600 p-6 text-white">
          <h2 className="text-xl font-bold">Contratar Aula</h2>
          <p className="text-blue-100 text-sm">Instrutor: {instructor.name}</p>
        </div>

        <div className="p-8 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Quantidade de Horas</label>
              <div className="flex items-center border rounded-xl overflow-hidden">
                <button 
                  onClick={() => setHours(Math.max(1, hours - 1))}
                  className="px-4 py-2 bg-slate-50 hover:bg-slate-100 text-lg font-bold"
                >
                  -
                </button>
                <div className="flex-grow text-center font-bold">{hours}h</div>
                <button 
                  onClick={() => setHours(hours + 1)}
                  className="px-4 py-2 bg-slate-50 hover:bg-slate-100 text-lg font-bold"
                >
                  +
                </button>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Data da Aula</label>
              <input 
                type="date" 
                className="w-full px-4 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
              />
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-2xl border border-dashed border-slate-200">
            <h3 className="text-xs font-bold text-slate-400 uppercase mb-4 tracking-wider">Resumo do Pagamento</h3>
            <div className="flex justify-between items-center mb-2">
              <span className="text-slate-600">Preço p/ Hora</span>
              <span className="font-semibold">R$ {instructor.pricePerHour.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-slate-600">Horas Contratadas</span>
              <span className="font-semibold">{hours}h</span>
            </div>
            <div className="h-px bg-slate-200 my-4"></div>
            <div className="flex justify-between items-center">
              <span className="text-lg font-bold">Total</span>
              <span className="text-2xl font-extrabold text-blue-600">R$ {total.toFixed(2)}</span>
            </div>
          </div>

          <div className="space-y-4">
            <div className="text-xs text-slate-400 text-center">
              Ao clicar em pagar, você concorda com nossos termos de uso e política de cancelamento.
            </div>
            <button 
              onClick={handlePayment}
              disabled={isProcessing}
              className="w-full bg-green-600 text-white py-4 rounded-2xl font-bold text-lg hover:bg-green-700 transition-all shadow-lg active:scale-95 disabled:opacity-50 flex items-center justify-center gap-3"
            >
              {isProcessing ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Processando...
                </>
              ) : (
                <>
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/></svg>
                  Pagar Online Agora
                </>
              )}
            </button>
            <button onClick={onClose} className="w-full text-slate-500 font-semibold py-2">Cancelar</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;
