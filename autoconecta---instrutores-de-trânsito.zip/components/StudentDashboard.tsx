
import React from 'react';
import { User, LessonBooking } from '../types';

interface StudentDashboardProps {
  user: User | null;
  bookings: LessonBooking[];
}

const StudentDashboard: React.FC<StudentDashboardProps> = ({ user, bookings }) => {
  if (!user) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 pb-24">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Profile Summary */}
        <div className="w-full md:w-1/3">
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100">
            <div className="flex flex-col items-center text-center">
              <div className="w-24 h-24 bg-blue-600 text-white rounded-full flex items-center justify-center text-4xl font-black mb-4 shadow-xl">
                {user.name.charAt(0)}
              </div>
              <h2 className="text-2xl font-extrabold text-slate-800">{user.name}</h2>
              <p className="text-slate-500 mb-6">{user.email}</p>
              
              <div className="w-full grid grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-2xl text-center border border-slate-100">
                  <span className="block text-2xl font-black text-blue-600">{bookings.length}</span>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Aulas</span>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl text-center border border-slate-100">
                  <span className="block text-2xl font-black text-green-600">
                    {bookings.reduce((acc, curr) => acc + curr.hours, 0)}h
                  </span>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Prática</span>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t">
              <h3 className="font-bold mb-4">Meus Objetivos</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                  <span className="text-sm text-slate-600">Concluir 20h de prática</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-slate-300"></div>
                  <span className="text-sm text-slate-600">Passar na prova teórica</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bookings List */}
        <div className="w-full md:w-2/3">
          <h2 className="text-2xl font-bold mb-6">Minhas Aulas Contratadas</h2>
          
          {bookings.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 border-2 border-dashed border-slate-200 text-center">
              <div className="text-slate-200 mb-4">
                <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
              </div>
              <p className="text-slate-500 font-medium">Você ainda não contratou nenhuma aula.</p>
              <p className="text-sm text-slate-400 mt-2">Explore os instrutores para começar seu treinamento!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {bookings.map(booking => (
                <div key={booking.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center font-bold">
                      {booking.hours}h
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800">Aula com {booking.instructorName}</h4>
                      <div className="flex items-center gap-2 text-sm text-slate-500">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                        {new Date(booking.date).toLocaleDateString('pt-BR')}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6 w-full md:w-auto justify-between border-t md:border-t-0 pt-4 md:pt-0">
                    <div>
                      <span className="text-xs text-slate-400 block uppercase font-bold tracking-wider">Pago</span>
                      <span className="font-bold text-slate-700">R$ {booking.totalAmount.toFixed(2)}</span>
                    </div>
                    <span className="px-3 py-1 bg-green-50 text-green-700 text-xs font-bold rounded-full uppercase">
                      Confirmado
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Quick Stats / Gamification */}
          <div className="mt-12 bg-indigo-600 rounded-3xl p-8 text-white relative overflow-hidden shadow-xl">
            <div className="relative z-10">
              <h3 className="text-2xl font-bold mb-2">Pronto para o exame?</h3>
              <p className="text-indigo-100 mb-6 max-w-sm">Use nosso assistente de IA para simular perguntas da prova teórica e chegue 100% confiante.</p>
              <button className="bg-white text-indigo-600 px-6 py-3 rounded-xl font-bold hover:bg-indigo-50 transition-colors shadow-lg">
                Iniciar Simulado IA
              </button>
            </div>
            <div className="absolute top-0 right-0 p-8 opacity-20 transform translate-x-1/4 -translate-y-1/4">
               <svg className="w-64 h-64" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71L12 2z"/></svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
