
import React from 'react';
import { VideoLesson } from '../types';

const MOCK_VIDEOS: VideoLesson[] = [
  {
    id: 'v1',
    title: 'Como Fazer a Baliza Perfeita',
    thumbnail: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&q=80&w=800',
    duration: '12:45',
    category: 'Manobras',
    description: 'Aprenda os pontos de referência definitivos para estacionar em qualquer vaga.',
    url: '#',
  },
  {
    id: 'v2',
    title: 'Mudança de Marchas Sem Soluço',
    thumbnail: 'https://images.unsplash.com/photo-1506015391300-4802dc74de2e?auto=format&fit=crop&q=80&w=800',
    duration: '08:20',
    category: 'Condução',
    description: 'Dicas práticas para dominar a embreagem e fazer trocas suaves.',
    url: '#',
  },
  {
    id: 'v3',
    title: 'Principais Placas de Trânsito',
    thumbnail: 'https://images.unsplash.com/photo-1541447271487-09612b3f49f7?auto=format&fit=crop&q=80&w=800',
    duration: '15:10',
    category: 'Teoria',
    description: 'Revisão completa das sinalizações que mais caem na prova do Detran.',
    url: '#',
  },
  {
    id: 'v4',
    title: 'Direção Defensiva na Chuva',
    thumbnail: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&q=80&w=800',
    duration: '10:30',
    category: 'Segurança',
    description: 'Como agir em situações adversas de clima e evitar aquaplanagem.',
    url: '#',
  },
];

const VideoLibrary: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8 pb-24">
      <div className="mb-10 text-center">
        <h2 className="text-3xl font-bold mb-4">Aulas em Vídeo Gratuitas</h2>
        <p className="text-slate-600">Acelere seu aprendizado com dicas práticas dos nossos melhores instrutores.</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {MOCK_VIDEOS.map(video => (
          <div key={video.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-100 hover:shadow-md transition-all cursor-pointer group">
            <div className="relative aspect-video overflow-hidden">
              <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="w-14 h-14 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-lg">
                  <svg className="w-8 h-8 ml-1" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
                </div>
              </div>
              <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                {video.duration}
              </div>
            </div>
            <div className="p-5">
              <span className="text-blue-600 text-xs font-bold uppercase tracking-wider mb-2 block">{video.category}</span>
              <h3 className="text-lg font-bold mb-2 group-hover:text-blue-600 transition-colors">{video.title}</h3>
              <p className="text-slate-500 text-sm">{video.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default VideoLibrary;
