
import React, { useState } from 'react';
import { Instructor, Category, User, LessonBooking } from '../types';
import PaymentModal from './PaymentModal';

const MOCK_INSTRUCTORS: Instructor[] = [
  {
    id: '1',
    name: 'Roberto Alencar',
    photo: 'https://picsum.photos/seed/roberto/200',
    rating: 4.9,
    reviewCount: 124,
    categories: [Category.CAR, Category.MOTORCYCLE],
    city: 'São Paulo - SP',
    bio: 'Especialista em alunos com medo de dirigir. 15 anos de experiência.',
    pricePerHour: 80,
    verified: true,
  },
  {
    id: '2',
    name: 'Ana Cláudia Silva',
    photo: 'https://picsum.photos/seed/ana/200',
    rating: 4.8,
    reviewCount: 89,
    categories: [Category.CAR],
    city: 'Rio de Janeiro - RJ',
    bio: 'Instrutora credenciada pelo Detran. Foco em aprovação rápida e segura.',
    pricePerHour: 75,
    verified: true,
  },
  {
    id: '3',
    name: 'Marcos Ferreira',
    photo: 'https://picsum.photos/seed/marcos/200',
    rating: 4.7,
    reviewCount: 56,
    categories: [Category.TRUCK, Category.BUS],
    city: 'Belo Horizonte - MG',
    bio: 'Treinamento para categorias profissionais e cargas perigosas.',
    pricePerHour: 120,
    verified: true,
  },
  {
    id: '4',
    name: 'Patrícia Mendes',
    photo: 'https://picsum.photos/seed/patricia/200',
    rating: 5.0,
    reviewCount: 32,
    categories: [Category.CAR],
    city: 'São Paulo - SP',
    bio: 'Paciência e didática moderna para jovens motoristas.',
    pricePerHour: 90,
    verified: true,
  },
];

interface InstructorListProps {
  user: User | null;
  onLoginRequired: () => void;
  onBookingComplete: (booking: LessonBooking) => void;
}

const InstructorList: React.FC<InstructorListProps> = ({ user, onLoginRequired, onBookingComplete }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [selectedInstructor, setSelectedInstructor] = useState<Instructor | null>(null);

  const filteredInstructors = MOCK_INSTRUCTORS.filter(inst => {
    const matchesSearch = inst.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          inst.city.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || inst.categories.includes(selectedCategory as Category);
    return matchesSearch && matchesCategory;
  });

  const handleHireClick = (inst: Instructor) => {
    if (!user) {
      onLoginRequired();
      return;
    }
    setSelectedInstructor(inst);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 pb-24">
      <div className="mb-10 text-center">
        <h2 className="text-3xl font-bold mb-4">Encontre seu Instrutor Ideal</h2>
        <p className="text-slate-600">Busque por cidade, nome ou categoria de veículo.</p>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 mb-8 flex flex-col md:flex-row gap-4 items-center">
        <div className="relative flex-grow w-full">
          <input 
            type="text" 
            placeholder="Cidade ou Nome do Instrutor..."
            className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-50 border-none focus:ring-2 focus:ring-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <svg className="w-5 h-5 absolute left-3 top-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
        </div>
        
        <select 
          className="w-full md:w-auto px-4 py-3 rounded-xl bg-slate-50 border-none focus:ring-2 focus:ring-blue-500 font-medium"
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value as any)}
        >
          <option value="All">Todas as Categorias</option>
          {Object.values(Category).map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredInstructors.length > 0 ? (
          filteredInstructors.map(inst => (
            <div key={inst.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-100 hover:shadow-lg transition-all group flex flex-col">
              <div className="relative h-48 overflow-hidden">
                <img src={inst.photo} alt={inst.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-2 py-1 rounded-lg flex items-center gap-1 shadow-md">
                  <span className="text-yellow-500">★</span>
                  <span className="font-bold">{inst.rating}</span>
                </div>
              </div>
              <div className="p-6 flex-grow flex flex-col">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-xl font-bold">{inst.name}</h3>
                  {inst.verified && (
                    <span className="text-blue-500" title="Verificado">
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
                    </span>
                  )}
                </div>
                <p className="text-slate-500 text-sm mb-4 flex items-center gap-1">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                  {inst.city}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {inst.categories.map(cat => (
                    <span key={cat} className="text-[10px] font-bold px-2 py-1 bg-blue-50 text-blue-700 rounded-md uppercase tracking-wider">
                      {cat}
                    </span>
                  ))}
                </div>
                <p className="text-slate-600 text-sm line-clamp-2 mb-6">
                  {inst.bio}
                </p>
                <div className="flex items-center justify-between mt-auto pt-4 border-t border-slate-50">
                  <div>
                    <span className="text-xl font-bold text-slate-900">R$ {inst.pricePerHour}</span>
                    <span className="text-slate-500 text-sm"> /h</span>
                  </div>
                  <button 
                    onClick={() => handleHireClick(inst)}
                    className="bg-blue-600 text-white px-5 py-2.5 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-md active:scale-95"
                  >
                    Contratar
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full py-20 text-center">
            <div className="text-slate-200 mb-4">
              <svg className="w-24 h-24 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.172 9.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </div>
            <p className="text-xl text-slate-400 font-medium">Nenhum instrutor encontrado para esses critérios.</p>
          </div>
        )}
      </div>

      {selectedInstructor && user && (
        <PaymentModal 
          instructor={selectedInstructor} 
          user={user} 
          onClose={() => setSelectedInstructor(null)} 
          onSuccess={(booking) => {
            setSelectedInstructor(null);
            onBookingComplete(booking);
          }}
        />
      )}
    </div>
  );
};

export default InstructorList;
