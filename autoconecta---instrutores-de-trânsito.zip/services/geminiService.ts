
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from "../types";

const SYSTEM_INSTRUCTION = `
Você é o 'AutoBot', um especialista em legislação de trânsito brasileira (CTB) e instrutor de direção experiente.
Seu objetivo é ajudar alunos que estão tirando a CNH ou habilitados com medo de dirigir.
Responda de forma encorajadora, clara e profissional.
Sempre que citar leis, tente ser específico sobre o Código de Trânsito Brasileiro.
Se o usuário perguntar sobre instrutores, explique que ele pode encontrá-los na aba 'Instrutores' do aplicativo.
`;

export async function getGeminiResponse(history: ChatMessage[]) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const contents = history.map(msg => ({
    role: msg.role === 'user' ? 'user' : 'model',
    parts: [{ text: msg.content }]
  }));

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    return response.text || "Desculpe, tive um problema ao processar sua resposta.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Ocorreu um erro ao conectar com o assistente. Verifique sua conexão.";
  }
}
